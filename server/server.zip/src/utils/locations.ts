export const locations = [
  "Andhra",
  "Pradesh",
  "Arunachal",
  "Pradesh",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal",
  "Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Assam",
  "Madhya",
  "Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odish",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttarakhand",
  "Uttar Pradesh",
  "West Bengal",
];

export type locationsTypes =
  | "Andhra"
  | "Pradesh"
  | "Arunachal"
  | "Pradesh"
  | "Bihar"
  | "Chhattisgarh"
  | "Goa"
  | "Gujarat"
  | "Haryana"
  | "Himachal"
  | "Pradesh"
  | "Jharkhand"
  | "Karnataka"
  | "Kerala"
  | "Assam"
  | "Madhya"
  | "Pradesh"
  | "Maharashtra"
  | "Manipur"
  | "Meghalaya"
  | "Mizoram"
  | "Nagaland"
  | "Odish"
  | "Punjab"
  | "Rajasthan"
  | "Sikkim"
  | "Tamil Nadu"
  | "Telangana"
  | "Tripura"
  | "Uttarakhand"
  | "Uttar Pradesh"
  | "West Bengal"
