// import { addCandidate } from "#/controllars/candidate";
// import { mustAuth } from "#/middleware/auth";
// import { Router } from "express";

// const router = Router();
// router.post("/add-candidate", mustAuth, addCandidate);
// export default router;