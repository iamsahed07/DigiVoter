import React from 'react'

function information() {
  return (
    <div>information</div>
  )
}

export default information