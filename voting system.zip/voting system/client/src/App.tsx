import { useState } from "react";
import Index from "./Index";
import Footer from "./components/Footer";
import Header from "./components/Header";
function App() {
  return (
    <>
      <Header></Header>
      <Index></Index>
      <Footer></Footer>
    </>
  );
}

export default App;
