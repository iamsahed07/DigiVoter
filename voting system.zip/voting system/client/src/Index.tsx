import React from "react";
import { Box, Typography } from "@mui/material";
import ClippedDrawer from "./components/Drawer";

function Index() {
  return (
    <Box>
      <ClippedDrawer></ClippedDrawer>
      {/* <Box sx={{ position: "fixed", zIndex: 2 }}>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione quis
          tenetur corporis itaque consectetur. Inventore deleniti, quod,
          sapiente optio, enim est ipsa suscipit repudiandae minima nesciunt
          debitis veniam eligendi eos!
        </p>
      </Box> */}
    </Box>
  );
}

export default Index;
