import React from "react";

type Props = {};

export default function Footer({}: Props) {
  return (
    <div
      style={{
        width: "100vw",
        height: "u60px",
        backgroundColor: "#4C3EDA",
        zIndex: "10000",
        position: "absolute",
        left: "0px",
        bottom: "0px",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <h4 style={{ color: "white", fontWeight: "normal" }}>
          PROJECT B.Tech CSE - 2024
        </h4>
      </div>
    </div>
  );
}
