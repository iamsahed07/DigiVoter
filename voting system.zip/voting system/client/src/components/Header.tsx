import { AppBar, Toolbar, Typography } from '@mui/material';
import React from 'react'

export const Header = () => {
  return (
    <AppBar
      position="fixed"
      sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, background: "#fff" }}
    >
      <Toolbar>
        <img src="../public/icon.svg" height={"40px"} width={"40px"}></img>
        <span> &nbsp; &nbsp;</span>
        <Typography
          variant="h4"
          noWrap
          component="div"
          color={"#4C3EDA"}
          sx={{ fontWeight: "bold",marginTop:0.8,}}
          fontFamily={"Anek Devanagari"}
        >
          DigiVoter
        </Typography>
      </Toolbar>
    </AppBar>
  );
}

export default Header;
