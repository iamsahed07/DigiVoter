import React from 'react'

function 
VoterRegistrationPage() {
  return (
    <div>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel saepe doloremque soluta facilis ipsa, dolorem voluptate fuga enim distinctio. Eaque corporis, modi saepe culpa iusto debitis ipsa. Incidunt animi magni eum officia in cumque accusamus a! Porro, cum soluta natus aspernatur totam quos omnis qui provident excepturi quas culpa, accusantium ut adipisci, itaque doloremque at! Et ea vel, quasi incidunt vero placeat reiciendis iusto est eum enim illum, dolorem laborum rerum quae perferendis beatae ut impedit error. Deserunt, dolor quas nesciunt asperiores porro doloremque, possimus obcaecati voluptatibus quaerat veritatis nostrum nulla recusandae ratione facere nemo? Quidem dolorum voluptatem magnam tenetur?
    </div>
  )
}

export default VoterRegistrationPage;

